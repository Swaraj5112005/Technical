Replace logo.png with club logo (recommended size 256x256).
